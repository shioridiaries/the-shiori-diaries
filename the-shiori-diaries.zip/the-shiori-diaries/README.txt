THE SHIORI DIARIES — PERSONAL BLOG STARTER

1. Open index.html in any web browser to see the blog.
2. To edit the introduction or About section, open index.html in a text editor and find the text you want to replace.
3. To add posts, find 'const entries=[' in the script near the bottom of index.html. Add an entry with title, category, excerpt, and body, following the existing examples.
4. To publish for free, create a GitHub repository and enable GitHub Pages (Settings > Pages > Deploy from branch). Upload index.html to the repository root. Or use a static hosting service that accepts HTML files.
5. This is a static starter website. It does not include an admin dashboard, login, comments, or automatic publishing. The included entries are illustrative drafts; edit them before publishing.
6. Do not publish identifiable patient details or private personal information.
